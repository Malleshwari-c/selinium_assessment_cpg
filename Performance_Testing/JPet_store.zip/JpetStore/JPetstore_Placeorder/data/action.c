Action()
{

	lr_start_transaction("01_Launch_Application");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("01_Launch_Application",LR_AUTO);

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790784674863\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive0*/

	lr_start_transaction("02_Select_Category");

	web_url("Open_Category", 
		"URL=https://jpetstore.aspectran.com/categories/FISH", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("02_Select_Category",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("03_Select_Product");

	web_url("Open_Product", 
		"URL=https://jpetstore.aspectran.com/products/FI-FW-02", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/categories/FISH", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("03_Select_Product",LR_AUTO);

	lr_think_time(24);

	lr_start_transaction("04_View_Item");

	web_url("Open_Item", 
		"URL=https://jpetstore.aspectran.com/products/FI-FW-02/items/EST-30", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/FI-FW-02", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("Product_Image", 
		"URL=https://jpetstore.aspectran.com/images/fish2.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://jpetstore.aspectran.com/products/FI-FW-02/items/EST-30", 
		"Snapshot=t5.inf", 
		LAST);

	lr_end_transaction("04_View_Item",LR_AUTO);

	lr_start_transaction("05_Add_To_Cart");

	web_url("Add_Item_To_Cart", 
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId=EST-30", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/products/FI-FW-02/items/EST-30", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("05_Add_To_Cart",LR_AUTO);

	lr_start_transaction("06_Proceed_To_Checkout");

	web_url("Open_Checkout_Form", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("06_Proceed_To_Checkout",LR_AUTO);

	lr_start_transaction("07_Login");

	web_submit_data("Submit_Login", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		LAST);

	lr_end_transaction("07_Login",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("08_Enter_Order_Details");

	web_submit_data("Submit_Order_Details", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("08_Enter_Order_Details",LR_AUTO);

	lr_start_transaction("09_Confirm_Order");

	web_submit_data("Confirm_Order", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	return 0;
}