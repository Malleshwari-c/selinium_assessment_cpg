Action()
{

	lr_start_transaction("01_Launch_ApplicationURL");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("Nop.customer=f2c1da1c-c145-4c81-a331-c26876317fe2; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utma=78382081.161295790.1790836827.1790836827.1790836827.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.28.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1790836827.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("NopCommerce.RecentlyViewedProducts=RecentlyViewedProductIds=75; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.29.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("01_Launch_ApplicationURL",LR_AUTO);

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive0*/

	lr_think_time(9);

	lr_start_transaction("02_Open_Registration");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("02_Open_Registration",LR_AUTO);

	lr_start_transaction("03_Register_UserButton");

	web_add_cookie("__utmb=78382081.30.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=l6bGjhtR9YNIXuj7wqOeSlgXRF8cNrHsd-6SPhFpxA_v-gcTR_BNfExN6KpzOWrQ58cMfQIJr3GXsFk8ssulj8GmjJ_KGDBqBP6eY-Rdx6s1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value=bhanu", ENDITEM, 
		"Name=LastName", "Value=priya", ENDITEM, 
		"Name=Email", "Value=notfound@gmail.com", ENDITEM, 
		"Name=Password", "Value=n12345", ENDITEM, 
		"Name=ConfirmPassword", "Value=n12345", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_add_cookie("__utmb=78382081.31.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("03_Register_UserButton",LR_AUTO);

	lr_think_time(21);

	lr_start_transaction("04_Continue_Shopping");

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.32.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("04_Continue_Shopping",LR_AUTO);

	lr_think_time(46);

	lr_start_transaction("5_product");

	web_url("Build your own cheap computer", 
		"URL=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("0000172_build-your-own-cheap-computer_300.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_300.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("0000173_build-your-own-cheap-computer_70.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000173_build-your-own-cheap-computer_70.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("0000174_build-your-own-cheap-computer_70.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000174_build-your-own-cheap-computer_70.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_70.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_70.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t9.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("5_product",LR_AUTO);

	lr_start_transaction("6_addtocart");

	web_add_cookie("__utmb=78382081.33.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(18);

	web_submit_data("1", 
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/72/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=product_attribute_72_5_18", "Value=53", ENDITEM, 
		"Name=product_attribute_72_6_19", "Value=54", ENDITEM, 
		"Name=product_attribute_72_3_20", "Value=57", ENDITEM, 
		"Name=addtocart_72.EnteredQuantity", "Value=1", ENDITEM, 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_47.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_47.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t11.inf", 
		LAST);

	lr_end_transaction("6_addtocart",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("7_shoppingcart");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/build-your-cheap-own-computer", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("0000172_build-your-own-cheap-computer_80.jpeg", 
		"URL=https://demowebshop.tricentis.com/content/images/thumbs/0000172_build-your-own-cheap-computer_80.jpeg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t13.inf", 
		LAST);

	lr_end_transaction("7_shoppingcart",LR_AUTO);

	lr_start_transaction("8_checkout");

	web_add_cookie("__utmb=78382081.34.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7121220", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	lr_end_transaction("8_checkout",LR_AUTO);

	lr_start_transaction("8_Billingaddress");

	web_add_cookie("__utmb=78382081.35.10.1790836827; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(58);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790839837639", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(57);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value=bhanu", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value=priya", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=notfound@gmail.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=abcd", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=bellary", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=ballari", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=siruguppa", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=583122", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=4568712345", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("8_Billingaddress",LR_AUTO);

	lr_think_time(21);

	lr_start_transaction("9_shippingaddress");

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159505", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=bhanu", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=priya", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=notfound@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("9_shippingaddress",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("10_shippingmethod");

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t18.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Next Day Air___Shipping.FixedRate", ENDITEM, 
		LAST);

	lr_end_transaction("10_shippingmethod",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("11_paymentmethod");

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t19.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CheckMoneyOrder", ENDITEM, 
		LAST);

	lr_end_transaction("11_paymentmethod",LR_AUTO);

	lr_think_time(24);

	lr_start_transaction("12_paymentInformation");

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t20.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("12_paymentInformation",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("13_confirm");

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t21.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t22.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("13_confirm",LR_AUTO);

	return 0;
}